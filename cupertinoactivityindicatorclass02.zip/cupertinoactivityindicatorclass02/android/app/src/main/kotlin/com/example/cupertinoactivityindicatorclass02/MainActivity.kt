package com.example.cupertinoactivityindicatorclass02

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
